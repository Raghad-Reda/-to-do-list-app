class TaskNode:
    def __init__(self, description, priority, completion_status=False):
        self.description = description
        self.priority = priority
        self.completion_status = completion_status
        self.next = None

class TaskLinkedList:
    def __init__(self):
        self.head = None

    def add_task(self, description, priority, completion_status=False):
        new_task = TaskNode(description, priority, completion_status)
        if not self.head:
            self.head = new_task
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_task

    def delete_task(self, description):
        if not self.head:
            return
        if self.head.description == description:
            self.head = self.head.next
            return
        current = self.head
        while current.next:
            if current.next.description == description:
                current.next = current.next.next
                return
            current = current.next

class HashTable:
    def __init__(self, size=100):
        self.size = size
        self.table = [None] * size

    def _hash(self, key):
        return hash(key) % self.size

    def insert(self, key, value):
        index = self._hash(key)
        if not self.table[index]:
            self.table[index] = []
        self.table[index].append((key, value))

    def search(self, key):
        index = self._hash(key)
        if self.table[index]:
            for k, v in self.table[index]:
                if k == key:
                    return v
        return None

    def delete(self, key):
        index = self._hash(key)
        if self.table[index]:
            for i, (k, v) in enumerate(self.table[index]):
                if k == key:
                    del self.table[index][i]
                    return


class PriorityNode:
    def __init__(self, priority):
        self.priority = priority
        self.tasks = []
        self.left = None
        self.right = None

class PriorityBST:
    def __init__(self):
        self.root = None

    def insert(self, priority, task):
        if not self.root:
            self.root = PriorityNode(priority)
            self.root.tasks.append(task)
        else:
            self._insert_recursive(self.root, priority, task)

    def _insert_recursive(self, node, priority, task):
        if priority == node.priority:
            node.tasks.append(task)
        elif priority < node.priority:
            if not node.left:
                node.left = PriorityNode(priority)
                node.left.tasks.append(task)
            else:
                self._insert_recursive(node.left, priority, task)
        else:
            if not node.right:
                node.right = PriorityNode(priority)
                node.right.tasks.append(task)
            else:
                self._insert_recursive(node.right, priority, task)

    def get_tasks_by_priority(self, priority):
        return self._search_recursive(self.root, priority)

    def _search_recursive(self, node, priority):
        if not node:
            return []
        if node.priority == priority:
            return node.tasks
        elif priority < node.priority:
            return self._search_recursive(node.left, priority)
        else:
            return self._search_recursive(node.right, priority)

import tkinter as tk
from tkinter import messagebox

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List Manager")
        self.task_list = TaskLinkedList()
        self.hash_table = HashTable()
        self.priority_bst = PriorityBST()

        # GUI Elements
        self.description_label = tk.Label(root, text="Task Description:")
        self.description_label.pack()
        self.description_entry = tk.Entry(root)
        self.description_entry.pack()

        self.priority_label = tk.Label(root, text="Priority (High/Medium/Low):")
        self.priority_label.pack()
        self.priority_entry = tk.Entry(root)
        self.priority_entry.pack()

        self.add_button = tk.Button(root, text="Add Task", command=self.add_task)
        self.add_button.pack()

        self.delete_button = tk.Button(root, text="Delete Task", command=self.delete_task)
        self.delete_button.pack()

        self.search_button = tk.Button(root, text="Search Task", command=self.search_task)
        self.search_button.pack()

        self.display_button = tk.Button(root, text="Display All Tasks", command=self.display_tasks)
        self.display_button.pack()

    def add_task(self):
        description = self.description_entry.get()
        priority = self.priority_entry.get()
        if description and priority:
            self.task_list.add_task(description, priority)
            self.hash_table.insert(description, description)
            self.priority_bst.insert(priority, description)
            messagebox.showinfo("Success", "Task added successfully!")
        else:
            messagebox.showwarning("Input Error", "Please fill in all fields.")

    def delete_task(self):
        description = self.description_entry.get()
        if description:
            self.task_list.delete_task(description)
            self.hash_table.delete(description)
            messagebox.showinfo("Success", "Task deleted successfully!")
        else:
            messagebox.showwarning("Input Error", "Please enter a task description.")

    def search_task(self):
        description = self.description_entry.get()
        if description:
            result = self.hash_table.search(description)
            if result:
                messagebox.showinfo("Search Result", f"Task found: {result}")
            else:
                messagebox.showinfo("Search Result", "Task not found.")
        else:
            messagebox.showwarning("Input Error", "Please enter a task description.")

    def display_tasks(self):
        tasks = []
        current = self.task_list.head
        while current:
            tasks.append(f"{current.description} (Priority: {current.priority})")
            current = current.next
        if tasks:
            messagebox.showinfo("All Tasks", "\n".join(tasks))
        else:
            messagebox.showinfo("All Tasks", "No tasks available.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()